from flask_wtf import FlaskForm
from wtforms.validators import DataRequired
from wtforms import StringField, PasswordField, BooleanField, SubmitField, TextAreaField, FileField
import sys
import urllib3


class Editor(FlaskForm):
    article = StringField('Название', validators=[DataRequired()])
    description = TextAreaField('Описание товара', validators=[DataRequired()])
    price = StringField('Цена товара', validators=[DataRequired()])
    photo = FileField(validators=[DataRequired()])

    submit = SubmitField('Создать товар')
