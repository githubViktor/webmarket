from flask_wtf import FlaskForm
from wtforms.validators import DataRequired
from wtforms import StringField, PasswordField, BooleanField, SubmitField
import sys
import urllib3


class RegisterForm(FlaskForm):
    user = StringField('Введите логин', validators=[DataRequired()])
    password = PasswordField('Введите пароль', validators=[DataRequired()])
    mail = StringField('Введите mail', validators=[DataRequired()])
    submit = SubmitField('Регистрация')

