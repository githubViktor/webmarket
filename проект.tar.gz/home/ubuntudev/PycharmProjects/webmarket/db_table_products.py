import sqlite3

class DB():
    def __init__(self, conn=0):
        conn = sqlite3.connect('product1.db', check_same_thread=False)
        self.conn = conn

    def get_connection(self):
        return self.conn

    def __del__(self):
        self.conn.close()


class UserModel():
    def __init__(self, connection):
        self.connection = connection
        cursor = self.connection.cursor()
        cursor.execute('''CREATE TABLE IF NOT EXISTS users1 
                        (id INTEGER PRIMARY KEY AUTOINCREMENT, 
                         user_name VARCHAR(50),
                         password_hash VARCHAR(128),
                         mail VARCHAR(100),
                         unicid VARCHAR(100),
                         status INTEGER
                         
                         )''')
        cursor.close()
        self.connection.commit()


    def insert(self, user_name, password_hash, mail, unicid, status=0):
             cursor = self.connection.cursor()
             cursor.execute('''INSERT INTO users1 
                      (user_name, password_hash, mail, unicid, status ) 
                      VALUES (?,?,?,?,?)''', (user_name, password_hash, mail, unicid, status))
             cursor.close()
             self.connection.commit()



    def exists(self, user_name, password_hash):
               cursor = self.connection.cursor()
               cursor.execute("SELECT * FROM users1 WHERE user_name = ? AND password_hash = ? AND status = 1",
               (user_name, password_hash))
               row = cursor.fetchone()
               return (True, row[0]) if row else (False,)


    def check(self, user_name):
               cursor = self.connection.cursor()
               cursor.execute("SELECT * FROM users1 WHERE user_name = ?",
               (user_name))
               row = cursor.fetchone()
               return (True, row[0]) if row else (False,)



    def update(self, unicid):
        cursor = self.connection.cursor()
        cursor.execute("UPDATE users1 SET status = 1 WHERE unicid = ?",
        (unicid,))
        cursor.close()
        self.connection.commit()




class ProductModel:
    def __init__(self, connection):
        self.connection = connection
        cursor = self.connection.cursor()
        cursor.execute('''CREATE TABLE IF NOT EXISTS products1234 
                        (id INTEGER PRIMARY KEY AUTOINCREMENT, 
                         title VARCHAR(100),
                         content VARCHAR(1000),
                         mark INTEGER,
                         price INTEGER

                         )''')

    def init_table(self):
        cursor = self.connection.cursor()
        cursor.execute('''CREATE TABLE IF NOT EXISTS products1234 
                        (id INTEGER PRIMARY KEY AUTOINCREMENT, 
                         title VARCHAR(100),
                         content VARCHAR(1000),
                         price INTEGER
                         mark INTEGER,
                        
                         
                         )''')



    def insert(self, title, content, price):
         cursor = self.connection.cursor()
         cursor.execute('''INSERT INTO products1234 
                      (title, content, price) 
                      VALUES (?,?,?)''', (title, content, price))
         cursor.close()
         self.connection.commit()



    def get_all(self, cond=""):
        cursor = self.connection.cursor()

        if cond == "high":
            cursor.execute("SELECT * FROM products1234 WHERE price > 500")
            rows = cursor.fetchall()
        elif cond == "equel":
            cursor.execute("SELECT * FROM products1234 WHERE price = 500")
            rows = cursor.fetchall()
        elif cond == "less":
            print('rfaerfger')
            cursor.execute("SELECT * FROM products1234 WHERE price < 500")
            rows = cursor.fetchall()
        elif cond == "":
            cursor.execute("SELECT * FROM products1234")
            rows = cursor.fetchall()
        return rows

    def get(self, name):
        cursor = self.connection.cursor()
        cursor.execute("SELECT * FROM products1234 WHERE title = ?", (str(name),))
        row = cursor.fetchone()
        return row

    def update(self, name, content):
        cursor = self.connection.cursor()
        cursor.execute('''UPDATE products1234 
               SET content = ?
               WHERE title = ?; ''', (content, name))




    def delete(self, name):
        cursor = self.connection.cursor()
        cursor.execute('''DELETE FROM products1234 WHERE title = ?''', (str(name),))
        cursor.close()
        self.connection.commit()


class CommentsModel:
    def __init__(self, connection):
        self.connection = connection
        cursor = self.connection.cursor()
        cursor.execute('''CREATE TABLE IF NOT EXISTS comments1
                        (id INTEGER PRIMARY KEY AUTOINCREMENT, 
                         username VARCHAR(1000),
                         productname VARCHAR(1000),
                         comment VARCHAR(1000)  

                         )''')
        cursor.close()
        self.connection.commit()

    def insert(self, username, productname, comment):
         cursor = self.connection.cursor()
         cursor.execute('''INSERT INTO comments1 
                      (username,productname, comment) 
                      VALUES (?,?,?)''', (username, productname, comment))
         cursor.close()
         self.connection.commit()

    def get_all(self, productname):
        cursor = self.connection.cursor()
        if productname:
            cursor.execute("SELECT * FROM comments1 WHERE productname = ?",
                       (str(productname),))
        else:
            cursor.execute("SELECT * FROM comments")
        rows = cursor.fetchall()
        return rows

    def update(self, name, comment):
        cursor = self.connection.cursor()
        cursor.execute('''UPDATE products1234 
               SET comments = ?
               WHERE title = ?; ''', (comment, name))
        cursor.close()
        self.connection.commit()







