from flask import Flask, render_template, Markup, url_for
from flask import request, redirect, session
from auth import LoginForm
from db_table_products import UserModel, DB, ProductModel, CommentsModel
from editor import Editor
from product import Product
from registration import RegisterForm
import sqlite3
from werkzeug.utils import secure_filename
import smtplib
import os
import random
import db_table_products


app = Flask(__name__)

app.config['SECRET_KEY'] = 'secretkey'

@app.route('/product/<name>', methods=['POST', 'GET'])
def product(name):
    if 'username' not in session:
        return redirect('/auth')
    db = DB()
    form = Product()
    modelcomments =CommentsModel(db.get_connection())
    product_model = ProductModel(db.get_connection())
    price = product_model.get(name)[4]
    link = '{}'.format(url_for('static', filename=name+'.png'))
    description = product_model.get(name)[2]


    if form.validate_on_submit():

        comments = form.comment.data
        modelcomments.insert(session["username"],name, comments)
        return redirect("/product/"+name)

    comments = modelcomments.get_all(name)


    return render_template('product.html/', name=name, link = link, description=description, comments=comments, price=price, form=form)

@app.route('/auth', methods=['POST', 'GET'])
def auth():

    form = LoginForm()
    print('login')

    if form.validate_on_submit():
        user_name = form.user.data
        password = form.password.data
        db = DB()
        user_model = UserModel(db.get_connection())

        exists = user_model.exists(user_name, password)

        print(exists[0])

        if (exists[0]):
            session['username'] = user_name
            session['user_id'] = exists[1]
            return redirect("/index")

    return render_template('auth.html', form=form)

@app.route("/confirm/<unicid>")
def confirm(unicid):
    db = DB()
    user_model = UserModel(db.get_connection())
    user_model.update(unicid)

    return redirect("/auth")


@app.route("/registration", methods=["GET", "POST"])
def test():


    def random_id(length):
        number = '0123456789'
        alpha = 'abcdefghijklmnopqrstuvwxyz'
        id = ''
        for i in range(0, length-1, 2):
            id += random.choice(number)
            id += random.choice(alpha)
        return id

    form = RegisterForm()

    if form.validate_on_submit():

        user_name = form.user.data
        password = form.password.data
        mail  = form.mail.data
        unicid = random_id(5)

        db = DB()

        user_model = UserModel(db.get_connection())

        check = user_model.check(user_name)

        if (check[0]):
            return render_template('registration.html', error_reg="пользователь существует", form=form)
        else:
            user_model.insert(user_name, password, mail, unicid)

            smtpObj = smtplib.SMTP('smtp.gmail.com', 587)


            smtpObj.starttls()
            smtpObj.login('sitemy97@gmail.com','difficultpassword')
            msg = 'From: <sitemy97@gmail.com>\nTo: <'+str(mail)+'>\nSubject: confirm\n\nhttp://140.176.177.94/confirm/'+str(unicid)
            smtpObj.sendmail("sitemy97@gmail.com", str(mail), msg)
            smtpObj.quit()

            return render_template('registration.html', error_reg="для завершения регистрации перейдите на ссылку отправленную вам на почтовый адресс", form=form)
    return render_template('registration.html', error_reg="", form=form)


@app.route('/create_product', methods=['POST', 'GET'])
def create_product():

    if 'username' not in session or session["username"] != "admin":
        return redirect('/auth')

    form = Editor()
    db = DB()
    print(DB)
    print(form.validate_on_submit())
    if form.validate_on_submit():
        print(1)
        article = form.article.data
        price = form.price.data
        description = form.description.data
        photo = form.photo.data
        filename = secure_filename(photo.filename).split('.')
        photo.save((os.path.join(
             'static', article+'.'+filename[1])))
        product_model = ProductModel(db.get_connection())
        product_model.insert(article, description, price)


        return redirect("/index")
    return render_template('product_editor.html', form=form)


@app.route('/logout')
def logout():
    session.pop('username',0)
    session.pop('user_id',0)
    return redirect("/index")                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            ('/auth')
list1 = []


@app.route('/search/<value>')
def search(value):
    db = DB()
    global list1
    product_model = ProductModel(db.get_connection())
    print(value)
    if value == "hight":
        list1 = product_model.get_all('hight')
        print(1)
        return redirect("/index")
    elif value == "equel":
        list1 = product_model.get_all('equel')
        return redirect("/index")
    elif value == "less":
        print(100000233)
        list1 = product_model.get_all('less')
        return redirect("/index")


@app.route('/')

@app.route('/index/')
def list():

    if 'username' not in session:
        return redirect('/auth')


    t = 0

    tr = '<tr>'
    tr1 = '</tr>'
    td = '<td>'
    td1 = '</td>'
    column = '<tr><td></td></tr>'
    list = []
    db = DB()
    product_model = ProductModel(db.get_connection())
    global list1
    print(list1)

    if list1 == []:
        list1 = product_model.get_all()

    if request.method == 'GET':
        list1 = product_model.get(request.form['search'])


    column = 0

    for i in list1:
        if column == 0:
            list.append(tr)

        if t > 0:
            list.append(tr1)
            t -= 1



        name = str(i[1])
        price = str(i[4])


        content ='''<div class="card">
            <img src="{}" alt="Avatar" style="
    width: 100px; height: 100px;">
            <div class="container">
            <h4><b>'''.format(url_for('static', filename=name+'.png'))+'''<a href="/product/'''+name+'''">'''+name+'''</a>'''+'''</b></h4>
            <p>стоимость: ''' +price+'''. </p>
            </div>
            </div>'''

        list.append('<td align="" width="45">'+content+'</td>')
        column += 1

        if column == 4:
            column = 0
            t += 1



    value = Markup(''.join(list))
    list1 = []

    return render_template('table.html', list1=value, username=session['username'])

if __name__ == '__main__':
    app.run(port=80, host='0.0.0.0', debug=True)





