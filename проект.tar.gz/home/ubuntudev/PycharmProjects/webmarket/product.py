from flask_wtf import FlaskForm
from wtforms.validators import DataRequired
from wtforms import StringField, PasswordField, BooleanField, SubmitField, TextAreaField, FileField
import sys
import urllib3


class Product(FlaskForm):

    comment = TextAreaField('Оставить комментарbй', validators=[DataRequired()])


    submit = SubmitField('отправить')
